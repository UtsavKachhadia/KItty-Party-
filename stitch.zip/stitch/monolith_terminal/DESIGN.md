# Design System Document: The Technical Monolith

## 1. Overview & Creative North Star
The "Technical Monolith" is the creative North Star for this design system. It moves away from the "friendly SaaS" aesthetic toward a high-density, architectural interface designed for precision. This is an agentic AI workflow tool for developers; it should feel like a high-end IDE or a sophisticated piece of lab equipment. 

We break the "template" look through **Intentional Information Density** and **Clinical Minimalism**. By utilizing a strictly flat, high-contrast 4-color palette and razor-thin 0.5px hairlines, we create a signature identity that prioritizes cognitive clarity over decorative fluff. Every pixel must serve a functional purpose.

---

## 2. Colors: Tonal Rigor
The palette is a high-contrast study in "Near-Black" and "Off-White," accented by functional status colors.

### The "No-Shadow" Depth Strategy
Since this system prohibits shadows and traditional gradients, we achieve depth through **Surface Nesting**. Use the `surface-container` tiers to define the UI’s physical hierarchy. 
- **Base Layer:** `surface` (#121212)
- **Primary Layout Sections:** `surface-container-low` (#1C1B1B)
- **Interactive/Floating Elements:** `surface-container-high` (#2A2A2A)

### The Micro-Rule (0.5px Borders)
While we avoid 1px "structural" lines, we use **0.5px Hairlines** using the `outline-variant` (#414755) token. These are not borders; they are "micro-rules" that mimic architectural drafting. They should be used sparingly to separate high-density data where background shifts aren't enough.

### Palette Mapping
- **Action/Running:** `primary` (#007AFF) — Use for active agent states.
- **Success:** `success` (#28A745) — Use for completed workflows.
- **Warning:** `tertiary` (#FFBF00) — Use for manual approval gates.
- **Error:** `error` (#DC3545) — Use for failed nodes or syntax issues.
- **Muted:** `secondary` (#6C757D) — For timestamps and non-essential metadata.

---

## 3. Typography: Editorial Utility
We use **Inter** for all UI elements to ensure maximum legibility at small sizes, paired with a strictly formatted Monospace for code.

- **Display (The Status):** `display-sm` (2.25rem). Used for large agent status counters or workflow titles.
- **Title (The Header):** `title-sm` (1rem / 16px). High contrast against background.
- **Body (The Workhorse):** `body-md` (13px). This is the default size for all text. It is intentionally small to allow for high-density information layouts.
- **Labels (The Metadata):** `label-sm` (11px). Use for tags, timestamps, and secondary descriptions.
- **Code (The Logic):** `monospace`. Use for JSON payloads and agent logs.

**Director’s Note:** Use `on-surface-variant` (#C1C6D7) for labels to create a natural hierarchy without changing the font size.

---

## 4. Elevation & Depth: Tonal Layering
Depth is achieved through the **Layering Principle** rather than shadows. 

1. **The Ground:** The main application background uses `background` (#131313).
2. **The Workbench:** The 3-column grid sections use `surface-container-low`.
3. **The Active Node:** Any selected or active element "lifts" by moving to `surface-container-highest` (#353534).

**Glassmorphism Fallback:** To maintain the "high-end" feel in dark mode, floating menus (like tooltips or context menus) may use a semi-transparent `surface-container-high` (85% opacity) with a `20px backdrop-blur`. This creates a "frosted obsidian" effect that feels premium without breaking the "no shadows" rule.

---

## 5. Components: Precision Primitives

### Buttons
- **Primary:** `primary` (#007AFF) background, `#F9F9F9` text. Flat. 8px border-radius.
- **Secondary:** Transparent background, 0.5px `outline` border, `#F9F9F9` text.
- **Tertiary:** No border, `#6C757D` text. For "Cancel" or low-priority actions.

### Input Fields
- **Container:** `surface-container-lowest` (#0E0E0E) with a 0.5px `outline-variant` border.
- **Text:** 13px Inter for labels, Monospace for the input value.
- **State:** On focus, the border changes to 0.5px `primary` (#007AFF).

### Workflow Cards
- **Construction:** No shadows. Use `surface-container-low` with a 0.5px border.
- **Spacing:** Use 12px internal padding (the "8-12px" rule).
- **Separation:** Do not use horizontal lines between list items. Instead, use a 4px vertical gap and a subtle background change (`surface-container-high`) on hover.

### Agentic Status Indicators
- **Pulse:** For "Running" states, use a non-gradient solid `primary` circle. 
- **Connectivity:** Use 0.5px lines to connect workflow nodes, colored by the state of the connection (Blue for active, Gray for idle).

---

## 6. Do’s and Don'ts

### Do:
- **Prioritize Density:** Developers prefer seeing more data at once. Use the 11px and 13px sizes effectively.
- **Use "Ghost Borders":** Use 0.5px borders at 20% opacity for extremely subtle sectioning.
- **Respect the Grid:** The 3-column grid is sacred. Top bar (44px), Left Sidebar (200px), Right Panel (280px). Ensure the center "Stage" is flexible.

### Don't:
- **No Gradients:** Do not use color transitions. Use solid tonal shifts.
- **No 1px Borders:** They look "clunky" in a high-end system. Always use 0.5px for that "retina-sharp" look.
- **No Decorative Icons:** Icons must have a functional purpose (e.g., a "Play" button). Do not use icons just to "fill space."
- **No Rounded Corners > 12px:** Stay within the 8-12px range to keep the UI feeling "industrial" rather than "bubbly."

---

## 7. Layout Specification
The app follows a rigid CSS Grid structure to reinforce the "Monolith" feel:
- **Outer Shell:** 100vh / 100vw. No scrollbars on the body.
- **Top Bar:** 44px fixed height. `surface-container-high`.
- **Sidebar (Left):** 200px. `surface-container-low`. Used for project navigation.
- **Main Stage (Center):** Auto-width. `surface`. This is where the agentic graph lives.
- **Inspector (Right):** 280px. `surface-container-low`. 0.5px left-border. Used for JSON inspection.